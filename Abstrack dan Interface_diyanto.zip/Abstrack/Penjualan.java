public class Penjualan extends Membuat_kue{

	
    public static void main(String[] args){
        //Membuat Instance/Objek dari Class Mambuat_Kue
        Penjualan kue_bronis = new Penjualan();
        kue_bronis.nama_kue("Bronis");
       	kue_bronis.bahan_bahan();
        

    }

   
}