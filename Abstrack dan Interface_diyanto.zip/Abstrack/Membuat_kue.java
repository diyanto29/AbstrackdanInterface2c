public class Membuat_kue extends Komponen{

    //Constractor 
    void nama_kue(String kue){
        System.out.println("Tutorial Membuat Kue "+ kue );
    }

    void bahan_bahan() {
        String bahan1 = "Tepung Terigu";
        String bahan2 = "Gula";
        String bahan3 = "Telur";
        System.out.println("====== BAHAN-BAHAN ======");
        System.out.println("1."+bahan1);
        System.out.println("2."+bahan2);
        System.out.println("3."+bahan3);
    }

    void peralatan() {
        String alat1 = "Oven";
        String alat2 = "Mixer";
        String alat3 = "Loyang";
        System.out.println("====== ALAT-ALAT ======");
        System.out.println("1."+alat1);
        System.out.println("2."+alat2);
        System.out.println("3."+alat3);
    }

  
    void proses_pembuatan() {
        System.out.println("====== PROSES ======");
        System.out.println("1.Aduk dan Campurkan Semua Bahan Pada Mixer");
        System.out.println("2.Masukan Pada Loyang");
        System.out.println("3.Oven Sampai Matang");
        System.out.println("4.Selesai");
    }
   
}