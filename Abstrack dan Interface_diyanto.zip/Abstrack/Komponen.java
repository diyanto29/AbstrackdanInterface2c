//kelas Abstrak
public abstract class Komponen {
    
    //Method Abstrak
    abstract void nama_kue(String kue);
    abstract void bahan_bahan();
    abstract void peralatan();
    abstract void proses_pembuatan();
}