public class Akademik implements Dosen, Mahasiswa{
	public void visiMisi(String visiMisi){
		System.out.println(visiMisi);
	}
	public void tampilId(int id){
		Mahasiswa.super.tampilId(170044);
		Dosen.super.tampilId(11212);
	}
	public void tampilNama(String nama){
		
		Mahasiswa.super.tampilNama("diyanto");
		Dosen.super.tampilNama("pa Facrul");
	}
	public static void main(String[] args) {
		Akademik akademik = new Akademik();
		akademik.visiMisi("Maju terus pantang mundur");
		akademik.tampilId(1703077);
		akademik.tampilNama("DIYANTO 2"); // Harus Di tanyakan ke bapak
	}
}