interface Mahasiswa{
	public void visiMisi(String visiMisi);
	default void tampilId(int nim){
		System.out.println("Nim Mahasiswa "+nim);
	}
	default void tampilNama(String nama){
		System.out.println("Nama Mahasiswa : "+nama);
	}
	
}