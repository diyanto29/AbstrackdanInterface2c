interface Dosen{
	public void visiMisi(String visiMisi);
	default void tampilId(int nip){
		System.out.println("Nip Dosen  " + nip);
	}
	default void tampilNama(String nama){
		System.out.println("Nama DOsennya : "+nama);
	}
	
}